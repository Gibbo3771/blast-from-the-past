﻿=== Pokemon Kanto Starters Cursor Set ===

By: pkmn2000

Download: http://www.rw-designer.com/cursor-set/pkmnkntstrtrs

Author's description:



==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.